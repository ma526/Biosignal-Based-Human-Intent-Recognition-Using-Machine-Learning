"""Biosignal-based human intent recognition (bsi)."""
__version__ = "0.1.0"
