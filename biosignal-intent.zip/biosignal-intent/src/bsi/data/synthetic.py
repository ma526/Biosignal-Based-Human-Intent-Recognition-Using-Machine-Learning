"""Synthetic multi-participant surface-EMG generator.

Produces realistic-looking sEMG so the full pipeline can be run without
hardware or a dataset download. Each gesture activates a fixed muscle
synergy (a pattern of channel amplitudes). Each simulated participant
differs in the ways real people do:

* electrode placement shift  -> the synergy pattern is rotated around the armband
* skin/fat impedance          -> per-channel gain
* muscle fibre composition    -> different spectral content (median frequency)
* effort / fatigue            -> per-repetition amplitude jitter
* noise                       -> 50/60 Hz powerline + baseline wander + white noise

Signal model per channel c:  x_c(t) = a_c(t) * s_c(t) + noise
where s_c is band-limited Gaussian noise (the classic stochastic sEMG model)
and a_c(t) is the activation envelope with onset/offset ramps.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from scipy import signal

GESTURES = ["rest", "fist", "wrist_flex", "wrist_ext", "radial_dev", "ulnar_dev", "extended_palm"]


@dataclass
class SyntheticConfig:
    n_subjects: int = 10
    n_channels: int = 8
    fs: int = 1000
    n_reps: int = 6
    rep_seconds: float = 3.0
    rest_seconds: float = 1.0
    powerline_hz: float = 60.0
    seed: int = 7


def _synergies(n_gestures: int, n_channels: int, rng: np.random.Generator) -> np.ndarray:
    """Smooth, spatially localised activation pattern per gesture (gestures x channels)."""
    ch = np.arange(n_channels)
    W = np.zeros((n_gestures, n_channels))
    W[0] = 0.03  # rest: near-silent
    for g in range(1, n_gestures):
        centre = rng.uniform(0, n_channels)
        width = rng.uniform(0.8, 2.2)
        d = np.minimum(np.abs(ch - centre), n_channels - np.abs(ch - centre))  # circular armband
        W[g] = np.exp(-(d ** 2) / (2 * width ** 2))
        if rng.random() < 0.6:  # some gestures co-activate an antagonist group
            c2 = (centre + n_channels / 2 + rng.normal(0, 1)) % n_channels
            d2 = np.minimum(np.abs(ch - c2), n_channels - np.abs(ch - c2))
            W[g] += rng.uniform(0.2, 0.6) * np.exp(-(d2 ** 2) / (2 * 1.2 ** 2))
        W[g] /= W[g].max()
    return W


def _rotate(pattern: np.ndarray, shift: float) -> np.ndarray:
    """Fractional circular shift of a channel pattern (electrode placement offset)."""
    n = pattern.shape[-1]
    k = np.fft.rfftfreq(n) * n
    spec = np.fft.rfft(pattern, axis=-1) * np.exp(-2j * np.pi * k * shift / n)
    return np.clip(np.fft.irfft(spec, n=n, axis=-1), 0, None)


def _envelope(n: int, fs: int, rng: np.random.Generator) -> np.ndarray:
    ramp = int(fs * rng.uniform(0.15, 0.35))
    env = np.ones(n)
    env[:ramp] = np.linspace(0, 1, ramp) ** 1.5
    env[-ramp:] = np.linspace(1, 0, ramp) ** 1.5
    # slow effort fluctuation
    env *= 1 + 0.15 * np.sin(2 * np.pi * rng.uniform(0.3, 1.0) * np.arange(n) / fs + rng.uniform(0, 6))
    return env


def generate(cfg: SyntheticConfig | None = None) -> dict:
    """Return a dataset dict with continuous recordings per subject.

    Output format (shared with the public-dataset loaders):
        {"fs": int, "gestures": list[str], "subjects": {sid: {"emg": (T, C), "label": (T,), "rep": (T,)}}}
    label is the gesture index, rep the repetition number (0 = between trials).
    """
    cfg = cfg or SyntheticConfig()
    rng = np.random.default_rng(cfg.seed)
    G = len(GESTURES)
    W = _synergies(G, cfg.n_channels, rng)
    nyq = cfg.fs / 2

    subjects = {}
    for s in range(cfg.n_subjects):
        shift = rng.normal(0, 0.9)                         # electrode placement (in channels)
        gain = rng.lognormal(0, 0.35, cfg.n_channels)      # impedance per channel
        f_lo = rng.uniform(15, 30)
        f_hi = rng.uniform(140, 260)                       # subject spectral signature
        b, a = signal.butter(4, [f_lo / nyq, f_hi / nyq], btype="band")
        Ws = _rotate(W, shift) * gain
        # small subject-specific distortion of the synergies themselves
        Ws *= rng.lognormal(0, 0.15, Ws.shape)

        emg, lab, rep = [], [], []
        n_trial = int(cfg.rep_seconds * cfg.fs)
        n_rest = int(cfg.rest_seconds * cfg.fs)
        for r in range(1, cfg.n_reps + 1):
            order = rng.permutation(np.arange(1, G))
            # session-to-session drift within a participant: slight band slip + synergy variation
            Wr = _rotate(Ws, rng.normal(0, 0.3)) * rng.lognormal(0, 0.25, Ws.shape)
            Wr[0] = Ws[0]
            for g in order:
                for seg_g, n_seg, seg_rep in ((0, n_rest, 0), (g, n_trial, r)):
                    src = signal.lfilter(b, a, rng.standard_normal((n_seg + 200, cfg.n_channels)), axis=0)[200:]
                    src /= src.std(axis=0, keepdims=True)
                    if seg_g == 0:
                        amp = np.full((n_seg, 1), 1.0) * Ws[0]
                    else:
                        effort = rng.uniform(0.5, 1.5)
                        amp = _envelope(n_seg, cfg.fs, rng)[:, None] * Wr[seg_g] * effort + Ws[0]
                    emg.append(amp * src)
                    lab.append(np.full(n_seg, seg_g))
                    rep.append(np.full(n_seg, seg_rep))
            # a dedicated labelled rest trial per repetition so 'rest' is a class too
            src = signal.lfilter(b, a, rng.standard_normal((n_trial + 200, cfg.n_channels)), axis=0)[200:]
            src /= src.std(axis=0, keepdims=True)
            emg.append(Ws[0] * src)
            lab.append(np.zeros(n_trial, int))
            rep.append(np.full(n_trial, r))

        x = np.concatenate(emg) * 0.5  # ~mV scale
        t = np.arange(len(x)) / cfg.fs
        noise = (
            0.02 * np.sin(2 * np.pi * cfg.powerline_hz * t)[:, None] * rng.uniform(0.5, 1.5, cfg.n_channels)
            + 0.03 * np.sin(2 * np.pi * 0.3 * t[:, None] + rng.uniform(0, 6, cfg.n_channels))
            + 0.06 * rng.standard_normal(x.shape)
        )
        subjects[f"S{s + 1:02d}"] = {
            "emg": (x + noise).astype(np.float32),
            "label": np.concatenate(lab).astype(np.int64),
            "rep": np.concatenate(rep).astype(np.int64),
        }
    return {"fs": cfg.fs, "gestures": GESTURES, "subjects": subjects, "name": "synthetic"}
