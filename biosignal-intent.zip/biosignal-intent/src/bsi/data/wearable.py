"""Loader for sessions recorded with hardware/record_session.py (custom armband)."""
from __future__ import annotations

from pathlib import Path

import numpy as np


def load_wearable(root: str | Path) -> dict:
    files = sorted(Path(root).glob("*.npz"))
    if not files:
        raise FileNotFoundError(f"No .npz sessions in {root}")
    subjects, fs, gestures = {}, None, None
    for f in files:
        d = np.load(f, allow_pickle=False)
        fs = int(d["fs"]); gestures = [str(g) for g in d["gestures"]]
        subjects[f.stem] = {"emg": d["emg"].astype(np.float32), "label": d["label"].astype(np.int64),
                            "rep": d["rep"].astype(np.int64)}
    return {"fs": fs, "gestures": gestures, "subjects": subjects, "name": "wearable"}
