"""Loaders for public EMG datasets.

All loaders return the same dict format as ``bsi.data.synthetic.generate``:
    {"fs", "gestures", "name", "subjects": {sid: {"emg": (T, C), "label": (T,), "rep": (T,)}}}

Supported datasets (download links and folder layout in docs/DATASETS.md):

1. UCI "EMG data for gestures" (Lobov et al., 2018) - 36 participants, 8-ch MYO
   armband, ~1 kHz, 7 gestures. Small, free, no registration: best first dataset
   for cross-participant work.
2. NinaPro DB5 (Pizzolato et al., 2017) - 10 participants, 2 x MYO (16 ch), 200 Hz,
   52 movements in 3 exercises. NinaPro DB2 (40 participants, 12-ch Delsys, 2 kHz)
   uses the same file format and works with the same loader (set fs=2000).
"""
from __future__ import annotations

from pathlib import Path

import numpy as np

UCI_GESTURES = ["rest", "fist", "wrist_flex", "wrist_ext", "radial_dev", "ulnar_dev", "extended_palm"]


def _reps_from_segments(label: np.ndarray, rep_offset: dict | None = None) -> tuple[np.ndarray, dict]:
    """Number each contiguous labelled segment per class: 1, 2, 3 ... (0 where label<0)."""
    rep = np.zeros_like(label)
    counts = dict(rep_offset or {})
    start = 0
    for i in range(1, len(label) + 1):
        if i == len(label) or label[i] != label[start]:
            c = int(label[start])
            if c >= 0:
                counts[c] = counts.get(c, 0) + 1
                rep[start:i] = counts[c]
            start = i
    return rep, counts


def load_uci_gestures(root: str | Path, include_palm: bool = False, max_subjects: int | None = None) -> dict:
    """Load the UCI 'EMG data for gestures' dataset.

    Expected layout:  root/01/1_raw_data_13-12_22.03.16.txt, root/01/2_raw_data_...txt, ...
    Each file: tab-separated columns  time | ch1..ch8 | class   (class 0 = unmarked).
    """
    root = Path(root)
    subj_dirs = sorted(p for p in root.iterdir() if p.is_dir() and p.name.isdigit())
    if max_subjects:
        subj_dirs = subj_dirs[:max_subjects]
    if not subj_dirs:
        raise FileNotFoundError(f"No numbered subject folders found in {root}")
    n_classes = 7 if include_palm else 6
    subjects = {}
    for d in subj_dirs:
        emg_l, lab_l, rep_l, counts = [], [], [], {}
        for f in sorted(d.glob("*.txt")):
            arr = np.loadtxt(f, skiprows=1)
            emg = arr[:, 1:9]
            cls = arr[:, 9].astype(int)
            lab = np.where((cls >= 1) & (cls <= n_classes), cls - 1, -1)  # class 1 (rest) -> 0
            rep, counts = _reps_from_segments(lab, counts)
            emg_l.append(emg); lab_l.append(lab); rep_l.append(rep)
        subjects[f"S{int(d.name):02d}"] = {
            "emg": np.concatenate(emg_l).astype(np.float32),
            "label": np.concatenate(lab_l).astype(np.int64),
            "rep": np.concatenate(rep_l).astype(np.int64),
        }
    return {"fs": 1000, "gestures": UCI_GESTURES[:n_classes], "subjects": subjects, "name": "uci_gestures"}


def load_ninapro(root: str | Path, exercise: int = 1, fs: int = 200, max_subjects: int | None = None) -> dict:
    """Load NinaPro DB5 (fs=200) or DB2 (fs=2000) for one exercise.

    Expected layout: root/s1/S1_E1_A1.mat ... (the unzipped per-subject archives).
    Uses 'restimulus' / 'rerepetition' (the relabelled, movement-aligned versions).
    Label 0 is rest; 1..K are the movements of that exercise.
    """
    from scipy.io import loadmat

    root = Path(root)
    files = sorted(root.rglob(f"S*_E{exercise}_A1.mat"), key=lambda p: int(p.name.split("_")[0][1:]))
    if max_subjects:
        files = files[:max_subjects]
    if not files:
        raise FileNotFoundError(f"No S*_E{exercise}_A1.mat files under {root}")
    subjects, n_cls = {}, 0
    for f in files:
        m = loadmat(f)
        emg = m["emg"].astype(np.float32)
        lab = m["restimulus"].ravel().astype(np.int64)
        rep = m["rerepetition"].ravel().astype(np.int64)
        # rest periods have rep 0: give them the number of the preceding repetition
        rest = lab == 0
        rep_ff = rep.copy()
        last = 1
        for i in range(len(rep_ff)):
            if rep_ff[i] > 0:
                last = rep_ff[i]
            elif rest[i]:
                rep_ff[i] = last
        n_cls = max(n_cls, int(lab.max()) + 1)
        sid = f"S{int(f.name.split('_')[0][1:]):02d}"
        subjects[sid] = {"emg": emg, "label": lab, "rep": rep_ff}
    gestures = ["rest"] + [f"E{exercise}_M{k}" for k in range(1, n_cls)]
    return {"fs": fs, "gestures": gestures, "subjects": subjects, "name": f"ninapro_E{exercise}"}
