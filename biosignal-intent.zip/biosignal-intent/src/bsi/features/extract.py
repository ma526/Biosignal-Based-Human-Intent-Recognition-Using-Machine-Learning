"""Hand-crafted EMG features: statistical/time-domain, FFT spectral, and wavelet.

All functions take windows X of shape (N, C, W) and return (N, C * k) feature
matrices plus a list of feature names, so features stay interpretable.
"""
from __future__ import annotations

import numpy as np
from scipy import stats

try:
    import pywt  # PyWavelets
    HAVE_PYWT = True
except ImportError:  # pragma: no cover - fallback used where pywt is absent
    HAVE_PYWT = False

# Daubechies-4 decomposition low-pass filter (same values as pywt.Wavelet('db4').dec_lo)
_DB4_LO = np.array([-0.010597401784997278, 0.032883011666982945, 0.030841381835986965,
                    -0.18703481171888114, -0.02798376941698385, 0.6308807679295904,
                    0.7148465705525415, 0.23037781330885523])
_DB4_HI = np.array([(-1) ** k * _DB4_LO[::-1][k] for k in range(len(_DB4_LO))])


def _names(prefix: list[str], n_ch: int) -> list[str]:
    return [f"ch{c + 1}_{p}" for c in range(n_ch) for p in prefix]


def _stack(feats: list[np.ndarray]) -> np.ndarray:
    """list of (N, C) -> (N, C*k) ordered channel-major."""
    return np.stack(feats, axis=-1).reshape(feats[0].shape[0], -1)


# ----------------------------------------------------------------------------- time domain
def time_domain(X: np.ndarray, zc_thresh: float | None = None):
    """Classic Hudgins set + statistical moments + Hjorth parameters + AR(4)."""
    N, C, W = X.shape
    d1 = np.diff(X, axis=-1)
    d2 = np.diff(d1, axis=-1)
    thr = zc_thresh if zc_thresh is not None else 0.01 * X.std(axis=-1, keepdims=True)
    mav = np.abs(X).mean(-1)
    rms = np.sqrt((X ** 2).mean(-1))
    var = X.var(-1)
    wl = np.abs(d1).sum(-1) / W
    zc = ((X[..., :-1] * X[..., 1:] < 0) & (np.abs(d1) >= thr)).sum(-1) / W
    ssc = ((d1[..., :-1] * d1[..., 1:] < 0) & (np.maximum(np.abs(d1[..., :-1]), np.abs(d1[..., 1:])) >= thr)).sum(-1) / W
    wamp = (np.abs(d1) >= 2 * thr).sum(-1) / W
    skew = stats.skew(X, axis=-1)
    kurt = stats.kurtosis(X, axis=-1)
    mobility = np.sqrt(d1.var(-1) / (var + 1e-12))
    complexity = np.sqrt(d2.var(-1) / (d1.var(-1) + 1e-12)) / (mobility + 1e-12)
    log_det = np.exp(np.log(np.abs(X) + 1e-8).mean(-1))
    ar = _ar_coeffs(X, order=4)  # (N, C, 4)
    feats = [mav, rms, var, wl, zc, ssc, wamp, skew, kurt, mobility, complexity, log_det] + [ar[..., i] for i in range(4)]
    names = ["MAV", "RMS", "VAR", "WL", "ZC", "SSC", "WAMP", "SKEW", "KURT", "HJ_MOB", "HJ_COMP", "LOGDET",
             "AR1", "AR2", "AR3", "AR4"]
    return _stack(feats), _names(names, C)


def _ar_coeffs(X: np.ndarray, order: int = 4) -> np.ndarray:
    """Autoregressive coefficients via Yule-Walker, vectorised over windows/channels."""
    N, C, W = X.shape
    Xc = X - X.mean(-1, keepdims=True)
    r = np.stack([(Xc[..., : W - k] * Xc[..., k:]).sum(-1) / W for k in range(order + 1)], -1)  # (N,C,p+1)
    R = np.empty((N, C, order, order))
    for i in range(order):
        for j in range(order):
            R[..., i, j] = r[..., abs(i - j)]
    R += 1e-9 * np.eye(order)
    return np.linalg.solve(R, r[..., 1:, None])[..., 0]


# ----------------------------------------------------------------------------- frequency (FFT)
def frequency_domain(X: np.ndarray, fs: int, bands=((20, 50), (50, 100), (100, 150), (150, 250), (250, 450))):
    """Spectral features from the Hann-windowed FFT power spectrum."""
    N, C, W = X.shape
    win = np.hanning(W)
    P = np.abs(np.fft.rfft(X * win, axis=-1)) ** 2
    f = np.fft.rfftfreq(W, 1 / fs)
    tot = P.sum(-1) + 1e-12
    mnf = (P * f).sum(-1) / tot                                    # mean frequency
    cum = np.cumsum(P, -1)
    mdf = f[np.argmax(cum >= 0.5 * cum[..., -1:], axis=-1)]       # median frequency
    pkf = f[P.argmax(-1)]                                          # peak frequency
    pn = P / tot[..., None]
    sent = -(pn * np.log(pn + 1e-12)).sum(-1)                      # spectral entropy
    sm1 = (P * f).sum(-1) / tot
    sm2 = np.sqrt((P * (f - sm1[..., None]) ** 2).sum(-1) / tot)   # spectral spread
    feats = [np.log(tot), mnf, mdf, pkf, sent, sm2]
    names = ["LOGPOW", "MNF", "MDF", "PKF", "SPEC_ENT", "SPEC_SPREAD"]
    for lo, hi in bands:
        if lo >= fs / 2:
            continue
        m = (f >= lo) & (f < min(hi, fs / 2))
        feats.append(P[..., m].sum(-1) / tot)
        names.append(f"BP_{lo}_{hi}")
    return _stack(feats), _names(names, C)


# ----------------------------------------------------------------------------- wavelet
def _dwt_numpy(x: np.ndarray, level: int):
    """Multilevel db4 DWT along last axis (symmetric padding). Returns [cA_n, cD_n, ..., cD_1]."""
    coeffs = []
    a = x
    L = len(_DB4_LO)
    from scipy.signal import fftconvolve
    shape = (1,) * (x.ndim - 1)
    for _ in range(level):
        pad = np.pad(a, [(0, 0)] * (a.ndim - 1) + [(L - 1, L - 1)], mode="symmetric")
        lo = fftconvolve(pad, _DB4_LO.reshape(shape + (L,)), mode="valid", axes=-1)[..., 1::2]
        hi = fftconvolve(pad, _DB4_HI.reshape(shape + (L,)), mode="valid", axes=-1)[..., 1::2]
        coeffs.append(hi)
        a = lo
    return [a] + coeffs[::-1]


def wavelet(X: np.ndarray, wavelet_name: str = "db4", level: int = 4):
    """Per sub-band: relative energy, std and mean absolute value of DWT coefficients."""
    N, C, W = X.shape
    level = min(level, int(np.log2(W / 8)))
    if HAVE_PYWT:
        coeffs = pywt.wavedec(X, wavelet_name, level=level, axis=-1)
    else:
        coeffs = _dwt_numpy(X, level)
    energies = [(c ** 2).sum(-1) for c in coeffs]
    tot = np.sum(energies, axis=0) + 1e-12
    feats, names = [], []
    bands = [f"A{level}"] + [f"D{level - i}" for i in range(level)]
    for b, c, e in zip(bands, coeffs, energies):
        feats += [e / tot, c.std(-1), np.abs(c).mean(-1)]
        names += [f"WT_{b}_RELE", f"WT_{b}_STD", f"WT_{b}_MAV"]
    return _stack(feats), _names(names, C)


# ----------------------------------------------------------------------------- all
def extract_all(X: np.ndarray, fs: int, groups=("time", "freq", "wavelet")):
    parts, names = [], []
    if "time" in groups:
        f, n = time_domain(X); parts.append(f); names += n
    if "freq" in groups:
        f, n = frequency_domain(X, fs); parts.append(f); names += n
    if "wavelet" in groups:
        f, n = wavelet(X); parts.append(f); names += n
    F = np.concatenate(parts, axis=1)
    F = np.nan_to_num(F, nan=0.0, posinf=0.0, neginf=0.0)
    return F.astype(np.float32), names
