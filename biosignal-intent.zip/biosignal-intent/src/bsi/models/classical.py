"""Feature-based classifiers (strong, fast baselines for EMG decoding)."""
from __future__ import annotations

from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
from sklearn.decomposition import PCA
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC


def make_model(name: str, pca_var: float | None = None, seed: int = 0):
    """Standardise -> (optional PCA keeping `pca_var` of variance) -> classifier."""
    clf = {
        "lda": LinearDiscriminantAnalysis(solver="lsqr", shrinkage="auto"),
        "svm": SVC(C=10, gamma="scale", kernel="rbf"),
        "rf": RandomForestClassifier(n_estimators=300, n_jobs=-1, random_state=seed),
        "logreg": LogisticRegression(C=1.0, max_iter=2000),
    }[name]
    steps = [StandardScaler()]
    if pca_var:
        steps.append(PCA(n_components=pca_var, svd_solver="full", random_state=seed))
    steps.append(clf)
    return make_pipeline(*steps)
