"""End-to-end deep models on raw (filtered) EMG windows: 1-D CNN, CNN-BiLSTM, Transformer.

Input to every model: tensor (batch, channels, time).
Requires PyTorch (pip install torch).
"""
from __future__ import annotations

import copy
import math

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F


# ----------------------------------------------------------------------------- models
class EMGCNN(nn.Module):
    """Temporal 1-D CNN with residual-free blocks and global average pooling."""

    def __init__(self, n_ch: int, n_cls: int, width: int = 64, dropout: float = 0.3):
        super().__init__()

        def block(cin, cout, k, s):
            return nn.Sequential(nn.Conv1d(cin, cout, k, stride=s, padding=k // 2), nn.BatchNorm1d(cout), nn.GELU())

        self.features = nn.Sequential(
            block(n_ch, width // 2, 7, 1),
            block(width // 2, width, 5, 2),
            block(width, width, 5, 2),
            block(width, width * 2, 3, 2),
            nn.Dropout(dropout),
            block(width * 2, width * 2, 3, 1),
        )
        self.head = nn.Sequential(nn.Dropout(dropout), nn.Linear(width * 2, n_cls))

    def forward(self, x):
        return self.head(self.features(x).mean(-1))


class EMGLSTM(nn.Module):
    """Strided conv stem (local feature learning) -> 2-layer BiLSTM -> attention pooling."""

    def __init__(self, n_ch: int, n_cls: int, hidden: int = 64, dropout: float = 0.3):
        super().__init__()
        self.stem = nn.Sequential(
            nn.Conv1d(n_ch, hidden, 5, stride=2, padding=2), nn.BatchNorm1d(hidden), nn.GELU(),
            nn.Conv1d(hidden, hidden, 5, stride=2, padding=2), nn.BatchNorm1d(hidden), nn.GELU(),
        )
        self.lstm = nn.LSTM(hidden, hidden, num_layers=2, batch_first=True, bidirectional=True, dropout=dropout)
        self.att = nn.Linear(2 * hidden, 1)
        self.head = nn.Sequential(nn.Dropout(dropout), nn.Linear(2 * hidden, n_cls))

    def forward(self, x):
        h = self.stem(x).transpose(1, 2)        # (B, T', H)
        h, _ = self.lstm(h)                     # (B, T', 2H)
        w = torch.softmax(self.att(h), dim=1)   # (B, T', 1)
        return self.head((w * h).sum(1))


class EMGTransformer(nn.Module):
    """Patch-embedding Transformer encoder with a learnable [CLS] token."""

    def __init__(self, n_ch: int, n_cls: int, win: int, patch: int = 10, d_model: int = 64,
                 n_heads: int = 4, n_layers: int = 3, dropout: float = 0.2):
        super().__init__()
        self.patch = patch
        self.embed = nn.Conv1d(n_ch, d_model, kernel_size=patch, stride=patch)
        n_tok = win // patch
        self.cls = nn.Parameter(torch.zeros(1, 1, d_model))
        self.pos = nn.Parameter(torch.randn(1, n_tok + 1, d_model) * 0.02)
        layer = nn.TransformerEncoderLayer(d_model, n_heads, dim_feedforward=4 * d_model, dropout=dropout,
                                           activation="gelu", batch_first=True, norm_first=True)
        self.encoder = nn.TransformerEncoder(layer, n_layers)
        self.norm = nn.LayerNorm(d_model)
        self.head = nn.Linear(d_model, n_cls)

    def forward(self, x):
        t = self.embed(x).transpose(1, 2)                       # (B, N_tok, D)
        t = torch.cat([self.cls.expand(len(t), -1, -1), t], 1)
        t = t + self.pos[:, : t.shape[1]]
        t = self.encoder(t)
        return self.head(self.norm(t[:, 0]))


def build(name: str, n_ch: int, n_cls: int, win: int) -> nn.Module:
    if name == "cnn":
        return EMGCNN(n_ch, n_cls)
    if name == "lstm":
        return EMGLSTM(n_ch, n_cls)
    if name == "transformer":
        patch = max(1, win // 20)
        return EMGTransformer(n_ch, n_cls, win=win - win % patch, patch=patch)
    raise ValueError(name)


# ----------------------------------------------------------------------------- training
def _augment(x: torch.Tensor) -> torch.Tensor:
    """Augmentations that mimic between-session / between-person variation."""
    B, C, _ = x.shape
    x = x * torch.exp(0.25 * torch.randn(B, C, 1, device=x.device))          # per-channel gain
    x = x + 0.05 * torch.randn_like(x)                                          # sensor noise
    shift = torch.randint(-1, 2, (B,), device=x.device)                        # electrode rotation +-1
    idx = (torch.arange(C, device=x.device)[None] - shift[:, None]) % C
    return torch.gather(x, 1, idx[..., None].expand_as(x))


def _prep(X: np.ndarray, mean: np.ndarray, std: np.ndarray, win: int) -> torch.Tensor:
    X = (X - mean) / std
    return torch.from_numpy(X[..., :win].astype(np.float32))


def fit_predict(name: str, Xtr, ytr, Xte, n_cls: int, epochs: int = 40, batch: int = 256, lr: float = 2e-3,
                val_frac: float = 0.1, patience: int = 8, augment: bool = True, seed: int = 0,
                device: str | None = None, verbose: bool = False):
    """Train `name` on (Xtr, ytr), early-stop on a random validation split, predict Xte.

    Xtr/Xte: (N, C, W) float arrays. Returns predicted labels for Xte.
    """
    torch.manual_seed(seed); np.random.seed(seed)
    device = device or ("cuda" if torch.cuda.is_available() else "mps" if torch.backends.mps.is_available() else "cpu")
    C, W = Xtr.shape[1], Xtr.shape[2]
    model = build(name, C, n_cls, W).to(device)
    win = W if name != "transformer" else W - W % model.patch

    # per-channel standardisation with *training* statistics only (no test leakage)
    mean = Xtr.mean(axis=(0, 2), keepdims=True)
    std = Xtr.std(axis=(0, 2), keepdims=True) + 1e-6
    rng = np.random.default_rng(seed)
    perm = rng.permutation(len(Xtr))
    n_val = int(val_frac * len(Xtr))
    vi, ti = perm[:n_val], perm[n_val:]
    Xt, yt = _prep(Xtr[ti], mean, std, win), torch.from_numpy(ytr[ti]).long()
    Xv, yv = _prep(Xtr[vi], mean, std, win), torch.from_numpy(ytr[vi]).long()

    opt = torch.optim.AdamW(model.parameters(), lr=lr, weight_decay=1e-2)
    steps = epochs * math.ceil(len(Xt) / batch)
    sched = torch.optim.lr_scheduler.OneCycleLR(opt, max_lr=lr, total_steps=steps, pct_start=0.15)
    best, best_state, bad = -1.0, None, 0
    for ep in range(epochs):
        model.train()
        order = torch.randperm(len(Xt))
        for i in range(0, len(Xt), batch):
            b = order[i:i + batch]
            xb, yb = Xt[b].to(device), yt[b].to(device)
            if augment:
                xb = _augment(xb)
            loss = F.cross_entropy(model(xb), yb, label_smoothing=0.1)
            opt.zero_grad(); loss.backward()
            nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            opt.step(); sched.step()
        acc = (_predict(model, Xv, device) == yv.numpy()).mean() if n_val else 0.0
        if verbose:
            print(f"  [{name}] epoch {ep + 1:02d} loss {loss.item():.3f} val_acc {acc:.3f}")
        if acc > best:
            best, best_state, bad = acc, copy.deepcopy(model.state_dict()), 0
        else:
            bad += 1
            if bad >= patience:
                break
    if best_state is not None:
        model.load_state_dict(best_state)
    return _predict(model, _prep(Xte, mean, std, win), device)


@torch.no_grad()
def _predict(model, X: torch.Tensor, device, batch: int = 1024) -> np.ndarray:
    model.eval()
    out = [model(X[i:i + batch].to(device)).argmax(1).cpu() for i in range(0, len(X), batch)]
    return torch.cat(out).numpy()
