"""Evaluation protocols for intent decoding across participants.

within      - per participant: train on some repetitions, test on held-out repetitions
loso        - leave-one-subject-out: train on N-1 participants, test on the unseen one
loso_calib  - LOSO plus a short calibration: the first `calib_reps` repetitions of the
              target participant are added to training (test on the remaining reps)

`fit_predict(Xtr, ytr, Xte) -> y_pred` is any callable, so classical and deep models
share the same protocol code.
"""
from __future__ import annotations

from typing import Callable

import numpy as np
import pandas as pd
from sklearn.metrics import accuracy_score, balanced_accuracy_score, confusion_matrix, f1_score


def _metrics(y, p):
    return {"acc": accuracy_score(y, p), "bal_acc": balanced_accuracy_score(y, p),
            "macro_f1": f1_score(y, p, average="macro")}


def run_protocol(protocol: str, fit_predict: Callable, X, y, subj, rep, n_cls: int,
                 train_reps=(1, 2, 3, 4), calib_reps: int = 1, verbose: bool = True):
    rows, cm = [], np.zeros((n_cls, n_cls), int)
    for s in np.unique(subj):
        tgt = subj == s
        if protocol == "within":
            tr = tgt & np.isin(rep, train_reps)
            te = tgt & ~np.isin(rep, train_reps)
        elif protocol == "loso":
            tr, te = ~tgt, tgt
        elif protocol == "loso_calib":
            reps_s = np.unique(rep[tgt])
            cal = reps_s[:calib_reps]
            tr = ~tgt | (tgt & np.isin(rep, cal))
            te = tgt & ~np.isin(rep, cal)
        else:
            raise ValueError(protocol)
        if te.sum() == 0 or tr.sum() == 0:
            continue
        p = fit_predict(X[tr], y[tr], X[te])
        m = _metrics(y[te], p)
        cm += confusion_matrix(y[te], p, labels=range(n_cls))
        rows.append({"subject": s, "protocol": protocol, "n_test": int(te.sum()), **m})
        if verbose:
            print(f"    {protocol:10s} {s}: acc={m['acc']:.3f}  macroF1={m['macro_f1']:.3f}", flush=True)
    return pd.DataFrame(rows), cm


def summarise(df: pd.DataFrame) -> pd.DataFrame:
    g = df.groupby(["model", "protocol"])
    out = g[["acc", "bal_acc", "macro_f1"]].agg(["mean", "std"])
    out.columns = [f"{a}_{b}" for a, b in out.columns]
    out["worst_subject_acc"] = g["acc"].min()
    return out.reset_index()
