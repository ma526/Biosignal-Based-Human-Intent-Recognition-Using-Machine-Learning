"""Figures: raw signals, spectra, embeddings, accuracy per participant, confusion matrix."""
from __future__ import annotations

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import seaborn as sns

PALETTE = ["#4C72B0", "#DD8452", "#55A868", "#C44E52", "#8172B3", "#937860", "#DA8BC3",
           "#8C8C8C", "#CCB974", "#64B5CD"]
plt.rcParams.update({"figure.dpi": 120, "axes.spines.top": False, "axes.spines.right": False,
                     "axes.titleweight": "bold", "font.size": 9})


def raw_signals(rec, fs, gestures, path, seconds=12):
    n = int(seconds * fs)
    x, lab = rec["emg"][:n], rec["label"][:n]
    t = np.arange(n) / fs
    C = x.shape[1]
    fig, axes = plt.subplots(C + 1, 1, figsize=(10, 1 + 0.7 * C), sharex=True,
                             gridspec_kw={"height_ratios": [1] * C + [0.6]})
    for c in range(C):
        axes[c].plot(t, x[:, c], lw=0.4, color=PALETTE[0])
        axes[c].set_ylabel(f"ch{c + 1}", rotation=0, labelpad=14)
        axes[c].set_yticks([])
    axes[-1].step(t, lab, color="k", lw=1)
    axes[-1].set_yticks(range(len(gestures)))
    axes[-1].set_yticklabels(gestures, fontsize=6)
    axes[-1].set_xlabel("time (s)")
    axes[0].set_title("Raw multi-channel EMG with gesture labels")
    fig.tight_layout(); fig.savefig(path); plt.close(fig)


def spectra(X, y, fs, gestures, path):
    f = np.fft.rfftfreq(X.shape[-1], 1 / fs)
    P = (np.abs(np.fft.rfft(X * np.hanning(X.shape[-1]), axis=-1)) ** 2).mean(1)  # mean over channels
    fig, ax = plt.subplots(figsize=(6, 3.5))
    for g in np.unique(y):
        ax.semilogy(f, P[y == g].mean(0), label=gestures[g], color=PALETTE[g % 10], lw=1.2)
    ax.set_xlabel("frequency (Hz)"); ax.set_ylabel("power")
    ax.set_title("Average FFT power spectrum per gesture")
    ax.legend(fontsize=7, frameon=False)
    fig.tight_layout(); fig.savefig(path); plt.close(fig)


def embeddings(results: dict, y, subj, gestures, path):
    """results: {method: (E, idx, trust)}; two rows: coloured by gesture / by participant."""
    methods = list(results)
    fig, axes = plt.subplots(2, len(methods), figsize=(4 * len(methods), 7.5), squeeze=False)
    subs = np.unique(subj)
    for j, m in enumerate(methods):
        E, idx, tw = results[m]
        for g in np.unique(y[idx]):
            k = y[idx] == g
            axes[0, j].scatter(E[k, 0], E[k, 1], s=3, alpha=0.6, color=PALETTE[g % 10], label=gestures[g])
        for i, s in enumerate(subs):
            k = subj[idx] == s
            axes[1, j].scatter(E[k, 0], E[k, 1], s=3, alpha=0.6, color=PALETTE[i % 10], label=s)
        axes[0, j].set_title(f"{m.upper()} - by gesture (trust={tw:.2f})")
        axes[1, j].set_title(f"{m.upper()} - by participant")
        for a in axes[:, j]:
            a.set_xticks([]); a.set_yticks([])
    axes[0, -1].legend(markerscale=4, fontsize=7, frameon=False, bbox_to_anchor=(1, 1), loc="upper left")
    axes[1, -1].legend(markerscale=4, fontsize=7, frameon=False, bbox_to_anchor=(1, 1), loc="upper left", ncol=1)
    fig.tight_layout(); fig.savefig(path); plt.close(fig)


def pca_variance(cumvar, path):
    fig, ax = plt.subplots(figsize=(5, 3))
    ax.plot(np.arange(1, len(cumvar) + 1), cumvar, color=PALETTE[0])
    for t, c in ((0.9, PALETTE[1]), (0.95, PALETTE[2]), (0.99, PALETTE[3])):
        n = int(np.searchsorted(cumvar, t) + 1)
        ax.axhline(t, ls=":", color=c, lw=1); ax.axvline(n, ls=":", color=c, lw=1)
        ax.text(n + 2, t - 0.05, f"{int(t * 100)}% @ {n} PCs", color=c, fontsize=7)
    ax.set_xlabel("number of principal components"); ax.set_ylabel("cumulative explained variance")
    ax.set_title("PCA on the feature set")
    fig.tight_layout(); fig.savefig(path); plt.close(fig)


def per_subject(df, path):
    fig, ax = plt.subplots(figsize=(10, 3.8))
    order = {"within": 0, "loso_calib": 1, "loso": 2}
    d = df.copy().sort_values(["protocol"], key=lambda c: c.map(order), kind="stable")
    d["model / protocol"] = d["model"] + " | " + d["protocol"]
    sns.barplot(data=d, x="subject", y="acc", hue="model / protocol", ax=ax, palette=PALETTE[: d["model / protocol"].nunique()])
    ax.set_ylim(0, 1.02); ax.set_ylabel("accuracy")
    ax.set_title("Decoding accuracy for each participant")
    ax.legend(fontsize=7, frameon=False, ncol=3, loc="upper right")
    fig.tight_layout(); fig.savefig(path); plt.close(fig)


def protocol_summary(df, path):
    fig, ax = plt.subplots(figsize=(7, 3.8))
    order = [p for p in ("within", "loso_calib", "loso") if p in df.protocol.unique()]
    sns.boxplot(data=df, x="model", y="acc", hue="protocol", hue_order=order, ax=ax,
                palette=PALETTE[:len(order)], fliersize=2, linewidth=0.8)
    ax.set_ylim(0, 1.02); ax.set_ylabel("accuracy (one point = one participant)")
    ax.set_title("Within-participant vs cross-participant decoding")
    ax.legend(fontsize=7, frameon=False)
    fig.tight_layout(); fig.savefig(path); plt.close(fig)


def confusion(cm, gestures, path, title):
    cmn = cm / cm.sum(1, keepdims=True).clip(min=1)
    fig, ax = plt.subplots(figsize=(5.2, 4.4))
    sns.heatmap(cmn, annot=True, fmt=".2f", cmap="Blues", vmin=0, vmax=1, ax=ax, cbar=False,
                xticklabels=gestures, yticklabels=gestures, annot_kws={"fontsize": 7})
    ax.set_xlabel("predicted"); ax.set_ylabel("true"); ax.set_title(title)
    plt.setp(ax.get_xticklabels(), rotation=45, ha="right")
    fig.tight_layout(); fig.savefig(path); plt.close(fig)


def feature_importance(names, importances, path, top=20):
    o = np.argsort(importances)[::-1][:top]
    fig, ax = plt.subplots(figsize=(5.5, 4.5))
    ax.barh(np.array(names)[o][::-1], importances[o][::-1], color=PALETTE[0])
    ax.set_xlabel("random-forest importance"); ax.set_title(f"Top {top} features")
    fig.tight_layout(); fig.savefig(path); plt.close(fig)
