"""Dimensionality reduction: PCA (linear, used inside models), t-SNE and UMAP (visualisation)."""
from __future__ import annotations

import numpy as np
from sklearn.decomposition import PCA
from sklearn.manifold import TSNE, trustworthiness
from sklearn.preprocessing import StandardScaler

try:
    import umap  # umap-learn
    HAVE_UMAP = True
except ImportError:  # pragma: no cover
    HAVE_UMAP = False


def pca_summary(F: np.ndarray, var_targets=(0.90, 0.95, 0.99)) -> dict:
    """How many principal components are needed to keep a given share of variance."""
    Z = StandardScaler().fit_transform(F)
    p = PCA().fit(Z)
    cum = np.cumsum(p.explained_variance_ratio_)
    return {"cumvar": cum, **{f"n_for_{int(t * 100)}pct": int(np.searchsorted(cum, t) + 1) for t in var_targets}}


def embed(F: np.ndarray, method: str = "tsne", n_components: int = 2, seed: int = 0, max_points: int = 4000):
    """2-D embedding of a feature matrix. Returns (embedding, indices_used, trustworthiness)."""
    rng = np.random.default_rng(seed)
    idx = np.arange(len(F)) if len(F) <= max_points else np.sort(rng.choice(len(F), max_points, replace=False))
    Z = StandardScaler().fit_transform(F[idx])
    Z50 = PCA(n_components=min(50, Z.shape[1]), random_state=seed).fit_transform(Z)  # standard pre-step
    if method == "pca":
        E = Z50[:, :n_components]
    elif method == "tsne":
        E = TSNE(n_components, perplexity=30, init="pca", learning_rate="auto", random_state=seed).fit_transform(Z50)
    elif method == "umap":
        if not HAVE_UMAP:
            raise ImportError("umap-learn not installed: pip install umap-learn")
        E = umap.UMAP(n_components=n_components, n_neighbors=30, min_dist=0.1, random_state=seed).fit_transform(Z50)
    else:
        raise ValueError(method)
    tw = trustworthiness(Z50, E, n_neighbors=10)
    return E, idx, tw
