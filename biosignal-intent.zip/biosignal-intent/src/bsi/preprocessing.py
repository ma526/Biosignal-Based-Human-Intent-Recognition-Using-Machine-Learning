"""Signal conditioning and sliding-window segmentation."""
from __future__ import annotations

import numpy as np
from scipy import signal


def filter_emg(x: np.ndarray, fs: int, band=(20.0, 450.0), notch_hz: float | None = 60.0, order: int = 4) -> np.ndarray:
    """Zero-phase band-pass (+ optional powerline notch and harmonics). x: (T, C)."""
    nyq = fs / 2
    lo, hi = band[0], min(band[1], 0.95 * nyq)
    if lo < hi:
        sos = signal.butter(order, [lo / nyq, hi / nyq], btype="band", output="sos")
        x = signal.sosfiltfilt(sos, x, axis=0)
    if notch_hz:
        f = notch_hz
        while f < 0.95 * nyq:
            b, a = signal.iirnotch(f / nyq, Q=30)
            x = signal.filtfilt(b, a, x, axis=0)
            f += notch_hz
    return x.astype(np.float32)


def window(
    rec: dict,
    fs: int,
    win_ms: float = 200,
    step_ms: float = 100,
    purity: float = 1.0,
    rest_ratio: float | None = 1.5,
    rng: np.random.Generator | None = None,
):
    """Cut a continuous recording into overlapping windows.

    A window is kept if >= `purity` of its samples share one label (>=0) and it
    lies inside one repetition. Rest windows are subsampled to at most
    `rest_ratio` x the mean count of an active class (rest dominates NinaPro).

    Returns X (N, C, W), y (N,), rep (N,).
    """
    rng = rng or np.random.default_rng(0)
    x, lab, rep = rec["emg"], rec["label"], rec["rep"]
    W = int(round(win_ms * fs / 1000))
    S = int(round(step_ms * fs / 1000))
    starts = np.arange(0, len(x) - W + 1, S)
    Xs, ys, rs = [], [], []
    for s in starts:
        l = lab[s:s + W]
        r = rep[s:s + W]
        vals, cnt = np.unique(l, return_counts=True)
        k = cnt.argmax()
        if vals[k] < 0 or cnt[k] < purity * W or r[0] != r[-1] or r[0] <= 0:
            continue
        Xs.append(x[s:s + W].T)
        ys.append(vals[k])
        rs.append(r[0])
    X = np.stack(Xs).astype(np.float32)
    y = np.array(ys)
    rp = np.array(rs)
    if rest_ratio is not None and (y == 0).any() and (y > 0).any():
        n_active = np.bincount(y)[1:]
        cap = int(rest_ratio * n_active[n_active > 0].mean())
        rest_idx = np.flatnonzero(y == 0)
        if len(rest_idx) > cap:
            drop = rng.choice(rest_idx, len(rest_idx) - cap, replace=False)
            keep = np.setdiff1d(np.arange(len(y)), drop)
            X, y, rp = X[keep], y[keep], rp[keep]
    return X, y, rp


def build_windows(data: dict, win_ms=200, step_ms=100, band=(20, 450), notch_hz=60.0, **kw):
    """Filter + window every subject. Returns X, y, subject_ids, reps (all aligned)."""
    fs = data["fs"]
    Xs, ys, ss, rs = [], [], [], []
    for sid, rec in data["subjects"].items():
        rec = dict(rec)
        rec["emg"] = filter_emg(rec["emg"], fs, band=band, notch_hz=notch_hz)
        X, y, r = window(rec, fs, win_ms, step_ms, **kw)
        Xs.append(X); ys.append(y); rs.append(r); ss.append(np.full(len(y), sid))
    return np.concatenate(Xs), np.concatenate(ys), np.concatenate(ss), np.concatenate(rs)
