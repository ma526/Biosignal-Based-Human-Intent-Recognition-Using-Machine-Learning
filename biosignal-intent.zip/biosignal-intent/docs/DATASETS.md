# Public EMG datasets supported

| Dataset | Participants | Sensors | Rate | Classes | Loader flag |
|---|---|---|---|---|---|
| UCI "EMG data for gestures" (Lobov et al., 2018) | 36 | 8-ch MYO armband | 1 kHz | 6 (+ extended palm) | `--dataset uci` |
| NinaPro DB5 (Pizzolato et al., 2017) | 10 | 2 x MYO = 16 ch | 200 Hz | 12 / 17 / 23 per exercise | `--dataset ninapro --ninapro-fs 200` |
| NinaPro DB2 (Atzori et al., 2014) | 40 | 12-ch Delsys Trigno | 2 kHz | 17 / 23 / 9 per exercise | `--dataset ninapro --ninapro-fs 2000` |

## 1. UCI EMG data for gestures (start here)

* Page: https://archive.ics.uci.edu/dataset/481/emg+data+for+gestures
* Free, no registration, ~60 MB. Gestures match the synthetic set exactly
  (rest, fist, wrist flexion/extension, radial/ulnar deviation, extended palm).
* Unzip so the layout is:

```
data/EMG_data_for_gestures-master/
    01/1_raw_data_13-12_22.03.16.txt
    01/2_raw_data_14-19_22.03.16.txt
    02/...
```

```bash
python scripts/run_pipeline.py --dataset uci --data-root data/EMG_data_for_gestures-master --out-dir results_uci
```
Recorded in Russia, so set `notch_hz: 50` in the config.

## 2. NinaPro DB5 / DB2

* Page: https://ninapro.hevs.ch/ (free account required). Download the per-subject zips.
* Layout: `data/ninapro_db5/s1/S1_E1_A1.mat`, `.../s2/S2_E1_A1.mat`, ...
* The loader uses `restimulus` and `rerepetition` (labels re-aligned to the actual movement).
* At 200 Hz (DB5) the band-pass upper edge is clipped to 95 Hz automatically and a 200 ms
  window is 40 samples, so the Transformer uses 2-sample patches.

```bash
python scripts/run_pipeline.py --dataset ninapro --data-root data/ninapro_db5 --ninapro-fs 200 --out-dir results_db5
```

## Other datasets worth adding later

* **GRABMyo** (PhysioNet, 43 participants, 3 sessions, 28 channels, 2 kHz) - best for cross-*session* studies; WFDB format (`pip install wfdb`).
* **putEMG** (44 participants, 24 ch, 5.12 kHz) - HDF5.
* **CapgMyo** (high-density 128-ch) - good for CNNs that treat the electrode grid as an image.

Write a loader returning the same dict as `bsi.data.public.load_uci_gestures` and everything else works unchanged.
