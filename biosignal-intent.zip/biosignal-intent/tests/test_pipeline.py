"""Unit tests: run with `pytest -q` (or `python tests/test_pipeline.py`)."""
import sys
import tempfile
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from bsi.data import public, synthetic  # noqa: E402
from bsi.features import extract  # noqa: E402
from bsi.preprocessing import build_windows, window  # noqa: E402


def _small():
    return synthetic.generate(synthetic.SyntheticConfig(n_subjects=2, n_reps=2))


def test_synthetic_shapes():
    d = _small()
    rec = d["subjects"]["S01"]
    assert rec["emg"].shape[1] == 8 and len(rec["emg"]) == len(rec["label"]) == len(rec["rep"])
    assert set(np.unique(rec["label"])) == set(range(len(d["gestures"])))


def test_windows_are_pure_and_within_one_rep():
    d = _small()
    X, y, s, r = build_windows(d, win_ms=200, step_ms=100)
    assert X.shape[1:] == (8, 200) and len(X) == len(y) == len(s) == len(r)
    assert (r > 0).all()


def test_rest_subsampling():
    rec = {"emg": np.random.randn(20000, 2).astype(np.float32),
           "label": np.r_[np.zeros(16000, int), np.ones(4000, int)], "rep": np.ones(20000, int)}
    X, y, _ = window(rec, 1000, 200, 100, rest_ratio=1.0)
    assert (y == 0).sum() <= (y == 1).sum()


def test_features_finite_and_named():
    X = np.random.randn(16, 4, 200).astype(np.float32)
    F, names = extract.extract_all(X, 1000)
    assert F.shape == (16, len(names)) and np.isfinite(F).all()


def test_fft_median_frequency_of_sine():
    fs, f0 = 1000, 120
    t = np.arange(400) / fs
    X = np.sin(2 * np.pi * f0 * t)[None, None]
    F, names = extract.frequency_domain(X, fs)
    mdf = F[0, names.index("ch1_MDF")]
    assert abs(mdf - f0) <= 5


def test_numpy_wavelet_filters_orthonormal():
    """With periodic extension an orthonormal DWT preserves energy exactly."""
    lo, hi = extract._DB4_LO, extract._DB4_HI
    x = np.random.randn(256); N = len(x)
    pc = lambda h: np.array([sum(h[k] * x[(n - k) % N] for k in range(len(h))) for n in range(N)])[::2]
    assert np.isclose((x ** 2).sum(), (pc(lo) ** 2).sum() + (pc(hi) ** 2).sum())
    coeffs = extract._dwt_numpy(np.random.randn(2, 3, 256), 3)
    assert [c.shape[-1] for c in coeffs][-1] >= 128  # D1 roughly half the window length


def test_uci_loader_on_mock_files():
    with tempfile.TemporaryDirectory() as tmp:
        for sid in ("01", "02"):
            p = Path(tmp) / sid; p.mkdir()
            n = 6000
            cls = np.zeros(n, int)
            for k, c in enumerate([1, 2, 3, 1, 2, 3]):
                cls[k * 1000 + 100: k * 1000 + 900] = c
            arr = np.column_stack([np.arange(n), np.random.randn(n, 8) * 1e-4, cls])
            np.savetxt(p / "1_raw_data.txt", arr, header="time ch1 ch2 ch3 ch4 ch5 ch6 ch7 ch8 class", comments="")
        d = public.load_uci_gestures(tmp)
        rec = d["subjects"]["S01"]
        assert set(np.unique(rec["label"])) == {-1, 0, 1, 2}
        assert rec["rep"][rec["label"] == 1].max() == 2


def test_ninapro_loader_on_mock_files():
    from scipy.io import savemat
    with tempfile.TemporaryDirectory() as tmp:
        n = 4000
        stim = np.zeros(n, int); rep = np.zeros(n, int)
        for k in range(4):
            stim[k * 1000 + 300: k * 1000 + 800] = 1 + k % 2
            rep[k * 1000 + 300: k * 1000 + 800] = 1 + k // 2
        savemat(Path(tmp) / "S1_E1_A1.mat", {"emg": np.random.randn(n, 16), "restimulus": stim[:, None],
                                            "rerepetition": rep[:, None]})
        d = public.load_ninapro(tmp, exercise=1, fs=200)
        assert d["gestures"][:3] == ["rest", "E1_M1", "E1_M2"]
        assert (d["subjects"]["S01"]["rep"][300:] > 0).all()


if __name__ == "__main__":
    for name, fn in list(globals().items()):
        if name.startswith("test_"):
            fn(); print("ok", name)
