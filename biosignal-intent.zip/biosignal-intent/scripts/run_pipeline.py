#!/usr/bin/env python
"""End-to-end pipeline: load -> filter/window -> features -> reduction -> models -> cross-participant evaluation.

Examples
    python scripts/run_pipeline.py                                   # synthetic data, all models
    python scripts/run_pipeline.py --dataset uci --data-root data/EMG_data_for_gestures-master
    python scripts/run_pipeline.py --dataset ninapro --data-root data/ninapro_db5 --ninapro-fs 200
    python scripts/run_pipeline.py --quick                           # fewer models, fast smoke test
"""
from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd
import yaml

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from bsi import viz  # noqa: E402
from bsi.data import public, synthetic, wearable  # noqa: E402
from bsi.evaluation import run_protocol, summarise  # noqa: E402
from bsi.features.extract import HAVE_PYWT, extract_all  # noqa: E402
from bsi.models.classical import make_model  # noqa: E402
from bsi.preprocessing import build_windows  # noqa: E402
from bsi.reduction import HAVE_UMAP, embed, pca_summary  # noqa: E402

try:
    import torch  # noqa: F401
    HAVE_TORCH = True
except ImportError:
    HAVE_TORCH = False


def load(cfg):
    if cfg["dataset"] == "synthetic":
        return synthetic.generate(synthetic.SyntheticConfig(**cfg["synthetic"], seed=cfg["seed"] + 7))
    if cfg["dataset"] == "uci":
        return public.load_uci_gestures(cfg["data_root"], max_subjects=cfg["max_subjects"])
    if cfg["dataset"] == "ninapro":
        return public.load_ninapro(cfg["data_root"], exercise=cfg["ninapro_exercise"], fs=cfg["ninapro_fs"],
                                   max_subjects=cfg["max_subjects"])
    if cfg["dataset"] == "wearable":
        return wearable.load_wearable(cfg["data_root"])
    raise ValueError(cfg["dataset"])


def subject_normalise(F, subj):
    """Z-score each feature within each participant (needs only unlabeled data from that person)."""
    F = F.copy()
    for s in np.unique(subj):
        k = subj == s
        F[k] = (F[k] - F[k].mean(0)) / (F[k].std(0) + 1e-6)
    return F


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default=str(Path(__file__).resolve().parents[1] / "configs/default.yaml"))
    ap.add_argument("--dataset"); ap.add_argument("--data-root"); ap.add_argument("--out-dir")
    ap.add_argument("--ninapro-fs", type=int); ap.add_argument("--max-subjects", type=int)
    ap.add_argument("--quick", action="store_true", help="LDA+SVM+CNN only, no t-SNE")
    a = ap.parse_args()
    cfg = yaml.safe_load(open(a.config))
    for k in ("dataset", "data_root", "out_dir", "ninapro_fs", "max_subjects"):
        if getattr(a, k) is not None:
            cfg[k] = getattr(a, k)
    if a.quick:
        cfg["classical_models"] = ["lda", "svm"]; cfg["deep_models"] = ["cnn"]; cfg["reduction"]["embed_methods"] = ["pca"]
    out = Path(cfg["out_dir"]); (out / "figures").mkdir(parents=True, exist_ok=True)
    t0 = time.time()

    # 1. data -----------------------------------------------------------------------------
    data = load(cfg)
    fs, gestures = data["fs"], data["gestures"]
    first = next(iter(data["subjects"].values()))
    print(f"[data] {data['name']}: {len(data['subjects'])} participants, {first['emg'].shape[1]} channels, {fs} Hz")
    viz.raw_signals(first, fs, gestures, out / "figures/01_raw_emg.png")

    # 2. preprocessing + windowing -------------------------------------------------------------
    pp = cfg["preprocessing"]
    X, y, subj, rep = build_windows(data, win_ms=pp["win_ms"], step_ms=pp["step_ms"], band=tuple(pp["band"]),
                                    notch_hz=pp["notch_hz"])
    n_cls = len(gestures)
    print(f"[windows] X={X.shape}  class counts={np.bincount(y, minlength=n_cls).tolist()}")
    viz.spectra(X, y, fs, gestures, out / "figures/02_spectra.png")

    # 3. features ------------------------------------------------------------------------------
    F, names = extract_all(X, fs, groups=tuple(cfg["features"]))
    print(f"[features] {F.shape[1]} features/window ({F.shape[1] // X.shape[1]} per channel); "
          f"wavelet backend={'pywt' if HAVE_PYWT else 'numpy-db4'}")
    if cfg["subject_feature_norm"]:
        F = subject_normalise(F, subj)

    # 4. dimensionality reduction ----------------------------------------------------------------
    ps = pca_summary(F)
    viz.pca_variance(ps["cumvar"], out / "figures/03_pca_variance.png")
    emb = {}
    for m in cfg["reduction"]["embed_methods"]:
        if m == "umap" and not HAVE_UMAP:
            print("[reduction] umap-learn not installed - skipping UMAP"); continue
        emb[m] = embed(F, m, seed=cfg["seed"])
        print(f"[reduction] {m}: trustworthiness={emb[m][2]:.3f}")
    viz.embeddings(emb, y, subj, gestures, out / "figures/04_embeddings.png")

    # 5-6. models x protocols --------------------------------------------------------------------
    all_rows, cms = [], {}
    pca_var = cfg["reduction"]["pca_var"]
    for mname in cfg["classical_models"]:
        print(f"[model] {mname} (features{' + PCA' if pca_var else ''})")
        fp = lambda Xtr, ytr, Xte, m=mname: make_model(m, pca_var, cfg["seed"]).fit(Xtr, ytr).predict(Xte)
        for proto in cfg["protocols"]:
            df, cm = run_protocol(proto, fp, F, y, subj, rep, n_cls, cfg["train_reps"], cfg["calib_reps"])
            df["model"] = mname; all_rows.append(df); cms[(mname, proto)] = cm

    if cfg["deep_models"] and not HAVE_TORCH:
        print("[model] PyTorch not installed - skipping deep models (pip install torch)")
    elif cfg["deep_models"]:
        from bsi.models.deep import fit_predict as deep_fp
        for mname in cfg["deep_models"]:
            print(f"[model] {mname} (raw EMG)")
            fp = lambda Xtr, ytr, Xte, m=mname: deep_fp(m, Xtr, ytr, Xte, n_cls, seed=cfg["seed"], **cfg["deep"])
            for proto in cfg["protocols"]:
                df, cm = run_protocol(proto, fp, X, y, subj, rep, n_cls, cfg["train_reps"], cfg["calib_reps"])
                df["model"] = mname; all_rows.append(df); cms[(mname, proto)] = cm

    res = pd.concat(all_rows, ignore_index=True)
    res.to_csv(out / "per_subject_results.csv", index=False)
    summ = summarise(res)
    summ.to_csv(out / "summary.csv", index=False)
    print("\n" + summ.round(3).to_string(index=False))

    viz.protocol_summary(res, out / "figures/05_protocols.png")
    best_model = summ[summ.protocol == "loso"].sort_values("acc_mean").iloc[-1]["model"] if "loso" in cfg["protocols"] else summ.iloc[0]["model"]
    viz.per_subject(res[res.model == best_model], out / "figures/06_per_subject.png")
    for proto in cfg["protocols"]:
        viz.confusion(cms[(best_model, proto)], gestures, out / f"figures/07_confusion_{best_model}_{proto}.png",
                      f"{best_model.upper()} - {proto}")
    rf = make_model("rf", None, cfg["seed"]).fit(F, y)
    viz.feature_importance(names, rf[-1].feature_importances_, out / "figures/08_feature_importance.png")

    meta = {"dataset": data["name"], "n_subjects": len(data["subjects"]), "fs": fs, "n_windows": int(len(y)),
            "n_features": int(F.shape[1]), "pca": {k: v for k, v in ps.items() if k != "cumvar"},
            "trustworthiness": {m: float(v[2]) for m, v in emb.items()},
            "backends": {"pywt": HAVE_PYWT, "umap": HAVE_UMAP, "torch": HAVE_TORCH},
            "runtime_s": round(time.time() - t0, 1)}
    json.dump(meta, open(out / "run_info.json", "w"), indent=2)
    print(f"\n[done] {meta['runtime_s']} s -> {out.resolve()}")


if __name__ == "__main__":
    main()
