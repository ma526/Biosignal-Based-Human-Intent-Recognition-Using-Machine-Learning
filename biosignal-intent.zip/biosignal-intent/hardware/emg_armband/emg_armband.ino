/*
  Custom wearable EMG armband firmware - streams N analog EMG channels at a fixed rate.

  Target board : ESP32 (12-bit ADC). Also works on Arduino Due / Teensy with minor pin changes.
  Front end    : one analog sEMG sensor per channel, e.g. MyoWare 2.0 (use the RAW / ENV-free output),
                 or an AD8232 / INA128-based board, placed around the forearm.
  Packet       : [0xA5][0x5A][uint32 sample_idx][uint16 ch0]...[uint16 chN-1][uint8 checksum]
                 little-endian; checksum = XOR of payload bytes. Parsed by hardware/record_session.py.

  SAFETY: power the sensors from a battery only (never from a mains-connected laptop charger
  while electrodes are on skin) - or use a USB isolator.
*/

#include <Arduino.h>

const uint8_t  N_CH         = 8;
const uint8_t  PINS[N_CH]   = {36, 39, 34, 35, 32, 33, 25, 26};   // ESP32 ADC1/ADC2-capable pins
const uint32_t FS_HZ        = 1000;                              // sampling rate
const uint32_t BAUD         = 921600;

hw_timer_t* timer = nullptr;
volatile bool tick = false;
uint32_t sample_idx = 0;

void IRAM_ATTR onTimer() { tick = true; }

void setup() {
  Serial.begin(BAUD);
  analogReadResolution(12);
  for (uint8_t c = 0; c < N_CH; c++) {
    analogSetPinAttenuation(PINS[c], ADC_11db);   // ~0-3.3 V input range
  }
  // Timer at 1 MHz, fire every 1e6 / FS_HZ ticks (Arduino-ESP32 core 3.x API)
  timer = timerBegin(1000000);
  timerAttachInterrupt(timer, &onTimer);
  timerAlarm(timer, 1000000 / FS_HZ, true, 0);
}

void loop() {
  if (!tick) return;
  tick = false;

  uint8_t buf[2 + 4 + 2 * N_CH + 1];
  buf[0] = 0xA5; buf[1] = 0x5A;
  memcpy(&buf[2], &sample_idx, 4);
  for (uint8_t c = 0; c < N_CH; c++) {
    uint16_t v = analogRead(PINS[c]);
    memcpy(&buf[6 + 2 * c], &v, 2);
  }
  uint8_t chk = 0;
  for (size_t i = 2; i < sizeof(buf) - 1; i++) chk ^= buf[i];
  buf[sizeof(buf) - 1] = chk;
  Serial.write(buf, sizeof(buf));
  sample_idx++;
}
