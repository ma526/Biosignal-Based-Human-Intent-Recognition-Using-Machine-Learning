#!/usr/bin/env python
"""Record a labelled gesture session from the custom EMG armband.

The participant follows on-screen prompts (rest -> gesture -> rest ...) for several
repetitions. Every sample is stored with the prompted gesture label and repetition
number, in the same format the pipeline uses for public datasets.

    pip install pyserial numpy
    python hardware/record_session.py --port /dev/ttyUSB0 --subject S01 --reps 6
    python hardware/record_session.py --simulate --subject S99          # no hardware: test the flow

Output: data/wearable/<subject>.npz  with emg (T, C) float32 volts, label (T,), rep (T,), fs, gestures.
Load all participants with  bsi.data.wearable.load_wearable("data/wearable").
"""
from __future__ import annotations

import argparse
import random
import struct
import sys
import threading
import time
from pathlib import Path

import numpy as np

GESTURES = ["rest", "fist", "wrist_flex", "wrist_ext", "radial_dev", "ulnar_dev", "extended_palm"]
HEADER = b"\xA5\x5A"


class ArmbandReader(threading.Thread):
    """Background thread that parses packets into a growing list of samples."""

    def __init__(self, port: str | None, n_ch: int, baud: int, fs: int, simulate: bool):
        super().__init__(daemon=True)
        self.n_ch, self.fs, self.simulate = n_ch, fs, simulate
        self.pkt = 2 + 4 + 2 * n_ch + 1
        self.samples: list[np.ndarray] = []
        self.dropped = 0
        self.running = True
        self.current_label, self.current_rep = 0, 0
        self.labels: list[int] = []
        self.reps: list[int] = []
        if not simulate:
            import serial  # pyserial
            self.ser = serial.Serial(port, baud, timeout=0.1)

    def _push(self, v: np.ndarray):
        self.samples.append(v); self.labels.append(self.current_label); self.reps.append(self.current_rep)

    def run(self):
        if self.simulate:
            t_next = time.perf_counter()
            while self.running:
                amp = 0.05 if self.current_label == 0 else 0.6
                self._push(2048 + 300 * amp * np.random.randn(self.n_ch))
                t_next += 1 / self.fs
                time.sleep(max(0, t_next - time.perf_counter()))
            return
        buf, last_idx = b"", None
        while self.running:
            buf += self.ser.read(4096)
            while len(buf) >= self.pkt:
                j = buf.find(HEADER)
                if j < 0:
                    buf = buf[-1:]; break
                if len(buf) - j < self.pkt:
                    buf = buf[j:]; break
                p = buf[j:j + self.pkt]; buf = buf[j + self.pkt:]
                payload = p[2:-1]
                chk = 0
                for b in payload:
                    chk ^= b
                if chk != p[-1]:
                    self.dropped += 1; continue
                idx = struct.unpack_from("<I", payload, 0)[0]
                vals = np.frombuffer(payload[4:], dtype="<u2").astype(np.float32)
                if last_idx is not None and idx != last_idx + 1:
                    self.dropped += idx - last_idx - 1
                last_idx = idx
                self._push(vals)

    def stop(self):
        self.running = False


def prompt(text: str, seconds: float):
    for remaining in np.arange(seconds, 0, -0.5):
        sys.stdout.write(f"\r  {text:<22s} {remaining:4.1f}s ")
        sys.stdout.flush(); time.sleep(0.5)
    sys.stdout.write("\n")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--port"); ap.add_argument("--baud", type=int, default=921600)
    ap.add_argument("--subject", required=True); ap.add_argument("--channels", type=int, default=8)
    ap.add_argument("--fs", type=int, default=1000); ap.add_argument("--reps", type=int, default=6)
    ap.add_argument("--hold", type=float, default=3.0); ap.add_argument("--rest", type=float, default=2.0)
    ap.add_argument("--vref", type=float, default=3.3); ap.add_argument("--adc-bits", type=int, default=12)
    ap.add_argument("--out", default="data/wearable"); ap.add_argument("--simulate", action="store_true")
    a = ap.parse_args()
    if not a.simulate and not a.port:
        ap.error("--port is required unless --simulate")

    r = ArmbandReader(a.port, a.channels, a.baud, a.fs, a.simulate); r.start()
    print(f"Recording {a.subject}: {a.reps} repetitions x {len(GESTURES) - 1} gestures. Ctrl+C to abort.")
    time.sleep(1.0)
    try:
        for rep in range(1, a.reps + 1):
            print(f"\n=== Repetition {rep}/{a.reps} ===")
            order = random.sample(GESTURES[1:], len(GESTURES) - 1)  # randomised to avoid order effects
            r.current_label, r.current_rep = 0, rep
            prompt("REST (relax hand)", a.hold)                     # labelled rest trial
            for g in order:
                r.current_label, r.current_rep = -1, 0              # transition: excluded
                prompt(f"get ready: {g}", a.rest)
                r.current_label, r.current_rep = GESTURES.index(g), rep
                prompt(f"HOLD {g.upper()}", a.hold)
            r.current_label, r.current_rep = -1, 0
    except KeyboardInterrupt:
        print("\naborted - saving what was recorded")
    finally:
        r.stop(); r.join(timeout=1)

    emg = np.stack(r.samples).astype(np.float32)
    emg = (emg - 2 ** (a.adc_bits - 1)) * a.vref / 2 ** a.adc_bits          # counts -> volts, centred
    out = Path(a.out); out.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(out / f"{a.subject}.npz", emg=emg, label=np.array(r.labels), rep=np.array(r.reps),
                        fs=a.fs, gestures=np.array(GESTURES))
    print(f"saved {emg.shape[0] / a.fs:.1f}s ({emg.shape}) to {out / (a.subject + '.npz')}; dropped packets={r.dropped}")


if __name__ == "__main__":
    main()
